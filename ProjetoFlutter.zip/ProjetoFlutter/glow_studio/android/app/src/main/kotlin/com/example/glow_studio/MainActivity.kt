package com.example.glow_studio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
