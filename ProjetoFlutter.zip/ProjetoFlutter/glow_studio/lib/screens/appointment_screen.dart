import 'package:flutter/material.dart';

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({super.key});

  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {

  final TextEditingController nomeController =
      TextEditingController();

  String servico = 'Corte Feminino';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Agendamento'),
        backgroundColor: Colors.pink,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [

            TextField(
              controller: nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField(
              value: servico,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Serviço',
              ),
              items: const [
                DropdownMenuItem(
                  value: 'Corte Feminino',
                  child: Text('Corte Feminino'),
                ),
                DropdownMenuItem(
                  value: 'Escova',
                  child: Text('Escova'),
                ),
                DropdownMenuItem(
                  value: 'Manicure',
                  child: Text('Manicure'),
                ),
                DropdownMenuItem(
                  value: 'Design de Sobrancelhas',
                  child: Text('Design de Sobrancelhas'),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  servico = value!;
                });
              },
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Agendamento realizado para ${nomeController.text}',
                    ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                foregroundColor: Colors.white,
              ),
              child: const Text(
                'Confirmar Agendamento',
              ),
            ),
          ],
        ),
      ),
    );
  }
}