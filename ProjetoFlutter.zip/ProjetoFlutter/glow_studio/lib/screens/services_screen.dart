import 'package:flutter/material.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Serviços'),
        backgroundColor: Colors.pink,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(15),
        children: const [
          Card(
            child: ListTile(
              leading: Icon(Icons.content_cut),
              title: Text('Corte Feminino'),
              subtitle: Text('R\$ 50'),
            ),
          ),

          Card(
            child: ListTile(
              leading: Icon(Icons.brush),
              title: Text('Escova'),
              subtitle: Text('R\$ 40'),
            ),
          ),

          Card(
            child: ListTile(
              leading: Icon(Icons.back_hand),
              title: Text('Manicure'),
              subtitle: Text('R\$ 30'),
            ),
          ),

          Card(
            child: ListTile(
              leading: Icon(Icons.face),
              title: Text('Design de Sobrancelhas'),
              subtitle: Text('R\$ 20'),
            ),
          ),
        ],
      ),
    );
  }
}